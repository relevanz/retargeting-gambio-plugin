<?php
/* -----------------------------------------------------------
Copyright (c) 2019 Releva GmbH - https://www.releva.nz
Released under the GNU General Public License (Version 2)
[http://www.gnu.org/licenses/gpl-2.0.html]
--------------------------------------------------------------
*/
require_once(__DIR__.'/src/lib/ClassLoader.php');
RelevanzTracking\Lib\ClassLoader::init()->addClassMap([
    'RelevanzTracking\\Lib\\Exception\\RelevanzException' => 'src/lib/exception/RelevanzException.php',
    'RelevanzTracking\\Lib\\Exception\\RelevanzExceptionMessage' => 'src/lib/exception/RelevanzExceptionMessage.php',

    'RelevanzTracking\\Lib\\ConfigurationInterface' => 'src/lib/ConfigurationInterface.php',
    'RelevanzTracking\\Lib\\Credentials' => 'src/lib/Credentials.php',
    'RelevanzTracking\\Lib\\HttpResponse' => 'src/lib/HttpResponse.php',
    'RelevanzTracking\\Lib\\RelevanzApi' => 'src/lib/RelevanzApi.php',

    'RelevanzTracking\\Lib\\Export\\Data\\ExportItemInterface' => 'src/lib/export/data/ExportItemInterface.php',
    'RelevanzTracking\\Lib\\Export\\Data\\ProductExportItem' => 'src/lib/export/data/ProductExportItem.php',
    'RelevanzTracking\\Lib\\Export\\ExporterInterface' => 'src/lib/export/ExporterInterface.php',
    'RelevanzTracking\\Lib\\Export\\CSVWriter' => 'src/lib/export/CSVWriter.php',
    'RelevanzTracking\\Lib\\Export\\CSVExporter' => 'src/lib/export/CSVExporter.php',
    'RelevanzTracking\\Lib\\Export\\JsonExporter' => 'src/lib/export/JsonExporter.php',
    'RelevanzTracking\\Lib\\Export\\Product\\CSVProductExporter' => 'src/lib/export/product/CSVProductExporter.php',
    'RelevanzTracking\\Lib\\Export\\Product\\JsonProductExporter' => 'src/lib/export/product/JsonProductExporter.php',

    'RelevanzTracking\\Shop\\GambioConfiguration' => 'src/shop/GambioConfiguration.php',
], __DIR__);
