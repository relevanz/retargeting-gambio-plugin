<?php
/* -----------------------------------------------------------
Copyright (c) 2019 Releva GmbH - https://www.releva.nz
Released under the GNU General Public License (Version 2)
[http://www.gnu.org/licenses/gpl-2.0.html]
--------------------------------------------------------------
*/
$t_language_text_section_content_array = array
(
    'relevanz_title' => 'releva.nz',
    'relevanz_description' => 'releva.nz - Technologie für personalisiertes Marketing',
    'relevanz_subtitle_conf' => 'Konfiguration',
    'relevanz_subtitle_stats' => 'Statistiken',
);