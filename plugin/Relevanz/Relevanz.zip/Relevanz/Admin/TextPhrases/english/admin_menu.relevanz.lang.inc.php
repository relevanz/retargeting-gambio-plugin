<?php
/* -----------------------------------------------------------
Copyright (c) 2019 Releva GmbH - https://www.releva.nz
Released under the GNU General Public License (Version 2)
[http://www.gnu.org/licenses/gpl-2.0.html]
--------------------------------------------------------------
*/
$t_language_text_section_content_array = array
(
    'BOX_HEADING_RELEVANZ' => 'releva.nz',
    'BOX_RELEVANZ_STATS' => 'Statistics',
    'BOX_RELEVANZ_CONF' => 'Configuration',
);
